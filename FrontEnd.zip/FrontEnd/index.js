document
  .getElementById("personForm")
  .addEventListener("submit", async function (e) {
    e.preventDefault();

    const nome = document.getElementById("nome").value;
    const cpf = document.getElementById("cpf").value;
    const telefone = document.getElementById("telefone").value;

    const data = {
      nome: nome,
      cpf: cpf,
      telefone: telefone,
    };

    try {
      const response = await fetch("http://localhost:3000/pessoas", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });

      if (response.ok) {
        document.getElementById("message").textContent =
          "Cadastro realizado com sucesso!";
        document.getElementById("personForm").reset();
      } else {
        document.getElementById("message").textContent = "Erro ao cadastrar.";
      }
    } catch (error) {
      document.getElementById("message").textContent =
        "Erro de comunicação ao servidor.";
    }
  });
